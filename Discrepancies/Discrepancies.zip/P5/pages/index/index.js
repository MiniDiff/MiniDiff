Page({
    data: {
        var_list: [0,1],
    }
})
  