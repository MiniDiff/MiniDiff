Page({
    data: {
        var_list: [{key: "js_list_value"}]
    }
})
  