Page({
  data: {
    ColorData:['red'],
  },
  onLoad() {
    this.setData({
      "ColorData[0]" : 'yellow',
    })
  },
})
