Page({
    data: {
        js_fun: function(){
            return "js data"
        }
    }
})
  