Page({
    data: {
        var_num: 0,
        var_num2: 0,
    },
    tap_handler: function(){
        this.setData({
            var_num: 0
        })
    }
})
  