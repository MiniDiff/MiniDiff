Page({
  data: {
    JSData:'Hellow',
  },
  TipCount:function(data){
    this.setData({JSData :"Change",})
  },
})
