Page({
    data: {
        var_num: 0,
    },
})
  