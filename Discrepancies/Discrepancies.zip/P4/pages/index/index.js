Page({
    data: {
        var_num: 0,
    },
    onLoad(){
        this.setData({})
    }
})
  