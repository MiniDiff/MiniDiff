Page({
    data: {
        var_list: function(){
            return [{key: "js_list_value"}]
        }
    }
})
  