Page({
    data: {
        var_list: 0
    },
    onLoad(){
        this.setData({
            var_list:[{key: "js_list_value"},{key: "js_list_value2"}]
        })
    }
})
  